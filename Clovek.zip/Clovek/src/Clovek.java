import java.util.Arrays;

public class Clovek implements Comparable<Clovek>{
    private String jmeno;
    private String prijmeni;


    public Clovek(String jmeno, String prijmeni) {
        this.jmeno = jmeno;
        this.prijmeni = prijmeni;

    }

    public int getSalary() {
        return 40000;
    }
    @Override
    public String toString() {
        return "Clovek{" + "jmeno='" + jmeno + "\'" + ", prijmeni='" + prijmeni + "\'" + "}";
    }

    @Override
    public int compareTo(Clovek o) {
        int vysledekporovnani = prijmeni.compareTo(o.prijmeni);
        if (vysledekporovnani == 0) {
            vysledekporovnani = jmeno.compareTo(o.jmeno);
        }
        return vysledekporovnani;
    }


    static void main() {
        Clovek[] podrizeni1 = {
                new Intern("Chleba", "Chleba"),
                new Intern("Cihla", "Cihla"),
                new Clovek("Obycejny", "Clovek")
        };
        Clovek[] zamestnanci = {
                new Manazer("Alois", "Jirasek", podrizeni1),

        };
        System.out.println(zamestnanci[0].toString());

        Arrays.sort(podrizeni1);

        for(int i = 0; i < podrizeni1.length; i++) {
            System.out.println(podrizeni1[i]);
        }
    }


}
